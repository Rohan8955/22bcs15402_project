import React from 'react';
import * as Icons from 'lucide-react';
import { Suggestion } from '../types';

interface SuggestionsListProps {
  suggestions: Suggestion[];
}

export const SuggestionsList: React.FC<SuggestionsListProps> = ({ suggestions }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <h2 className="text-lg font-semibold mb-4">Energy Saving Suggestions</h2>
      <div className="space-y-4">
        {suggestions.map((suggestion) => {
          const Icon = Icons[suggestion.icon as keyof typeof Icons];
          return (
            <div
              key={suggestion.id}
              className="flex items-start p-4 border rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex-shrink-0">
                <div className={`p-2 rounded-lg ${
                  suggestion.priority === 'high'
                    ? 'bg-red-100 text-red-600'
                    : suggestion.priority === 'medium'
                    ? 'bg-yellow-100 text-yellow-600'
                    : 'bg-green-100 text-green-600'
                }`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>
              <div className="ml-4 flex-1">
                <h3 className="text-sm font-medium">{suggestion.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{suggestion.description}</p>
                <p className="text-sm font-medium text-green-600 mt-2">
                  Potential savings: ${suggestion.savingPotential}/year
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};