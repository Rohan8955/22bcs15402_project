import React from 'react';
import * as Icons from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: keyof typeof Icons;
  trend?: number;
  className?: string;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  value,
  icon,
  trend,
  className = '',
}) => {
  const Icon = Icons[icon];
  
  return (
    <div className={`bg-white rounded-xl p-6 shadow-sm ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-600 text-sm font-medium">{title}</h3>
        <Icon className="w-5 h-5 text-blue-600" />
      </div>
      <div className="flex items-end justify-between">
        <p className="text-2xl font-semibold">{value}</p>
        {trend !== undefined && (
          <span className={`flex items-center text-sm ${trend >= 0 ? 'text-red-500' : 'text-green-500'}`}>
            {trend >= 0 ? <Icons.TrendingUp className="w-4 h-4 mr-1" /> : <Icons.TrendingDown className="w-4 h-4 mr-1" />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
    </div>
  );
};