import React from 'react';
import { DashboardCard } from './components/DashboardCard';
import { EnergyChart } from './components/EnergyChart';
import { SuggestionsList } from './components/SuggestionsList';
import { energyData, suggestions } from './data/mockData';

function App() {
  // Calculate metrics
  const currentMonthUsage = energyData
    .slice(-30)
    .reduce((sum, day) => sum + day.consumption, 0);
  
  const previousMonthUsage = energyData
    .slice(-60, -30)
    .reduce((sum, day) => sum + day.consumption, 0);
  
  const usageChange = ((currentMonthUsage - previousMonthUsage) / previousMonthUsage) * 100;
  
  const estimatedBill = currentMonthUsage * 0.15;
  const previousBill = previousMonthUsage * 0.15;
  const billChange = ((estimatedBill - previousBill) / previousBill) * 100;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Energy Dashboard</h1>
            <p className="text-gray-600">Monitor and optimize your energy consumption</p>
          </div>
          <img
            src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=100&h=100"
            alt="Profile"
            className="w-10 h-10 rounded-full"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <DashboardCard
            title="Monthly Usage"
            value={`${currentMonthUsage.toFixed(1)} kWh`}
            icon="Zap"
            trend={Number(usageChange.toFixed(1))}
          />
          <DashboardCard
            title="Estimated Bill"
            value={`$${estimatedBill.toFixed(2)}`}
            icon="DollarSign"
            trend={Number(billChange.toFixed(1))}
          />
          <DashboardCard
            title="Carbon Footprint"
            value={`${(currentMonthUsage * 0.85).toFixed(1)} kg`}
            icon="Leaf"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <EnergyChart data={energyData} />
          </div>
          <div className="lg:col-span-1">
            <SuggestionsList suggestions={suggestions} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;