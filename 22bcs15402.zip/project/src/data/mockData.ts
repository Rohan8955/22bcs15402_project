import { EnergyData, Suggestion } from '../types';
import { addDays, format, subDays } from 'date-fns';

// Generate last 30 days of energy data
const generateEnergyData = (): EnergyData[] => {
  const data: EnergyData[] = [];
  const today = new Date();

  for (let i = 29; i >= 0; i--) {
    const date = subDays(today, i);
    const baseConsumption = 20 + Math.random() * 10;
    const consumption = baseConsumption + (date.getDay() === 0 || date.getDay() === 6 ? 5 : 0);
    
    data.push({
      date: format(date, 'yyyy-MM-dd'),
      consumption: Number(consumption.toFixed(2)),
      cost: Number((consumption * 0.15).toFixed(2))
    });
  }

  return data;
};

export const energyData = generateEnergyData();

export const suggestions: Suggestion[] = [
  {
    id: 1,
    title: 'Switch to LED Bulbs',
    description: 'Replace traditional bulbs with LED alternatives to save up to 75% on lighting costs.',
    savingPotential: 120,
    priority: 'high',
    icon: 'Lightbulb'
  },
  {
    id: 2,
    title: 'Optimize Thermostat',
    description: 'Adjust your thermostat by 1°C to save up to 10% on heating/cooling costs.',
    savingPotential: 200,
    priority: 'high',
    icon: 'Thermometer'
  },
  {
    id: 3,
    title: 'Seal Air Leaks',
    description: 'Check and seal windows and doors to prevent energy waste.',
    savingPotential: 80,
    priority: 'medium',
    icon: 'Wind'
  },
  {
    id: 4,
    title: 'Regular Maintenance',
    description: 'Schedule regular HVAC maintenance to ensure optimal efficiency.',
    savingPotential: 150,
    priority: 'medium',
    icon: 'Settings'
  }
];