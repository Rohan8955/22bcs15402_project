export interface EnergyData {
  date: string;
  consumption: number;
  cost: number;
}

export interface Suggestion {
  id: number;
  title: string;
  description: string;
  savingPotential: number;
  priority: 'high' | 'medium' | 'low';
  icon: string;
}